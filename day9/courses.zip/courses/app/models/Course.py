from system.core.model import Model

class Course(Model):
    def __init__(self):
        super(Course, self).__init__()
    def get_all_courses(self):
        query = 'SELECT course_id, title, description, DATE_FORMAT(created_at, "%b %e, %Y %l:%i %p") AS created_at FROM courses ORDER BY created_at DESC'
        return self.db.query_db(query)
    def get_course_by_id(self, course_id):
        query = 'SELECT course_id, title, description FROM courses WHERE course_id=%s'
        data = [course_id]
        return self.db.query_db(query, data)
    def add_course(self, course):
        query = 'INSERT INTO courses (title, description, created_at, updated_at) VALUES (%s, %s, NOW(), NOW())'
        data = [course['title'], course['description']]
        return self.db.query_db(query, data)
    def delete_course(self, course_id):
        query = 'DELETE FROM courses WHERE course_id=%s'
        data = [course_id]
        return self.db.query_db(query, data)
