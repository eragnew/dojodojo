"""
    Routes Configuration File

    Put Routing rules here
"""
from system.core.router import routes


routes['default_controller'] = 'Courses'
routes['POST']['/courses/add'] = 'Courses#create'
routes['/courses/destroy/<course_id>'] = 'Courses#destroy_page'
routes['POST']['/courses/destroy/<course_id>/confirmed'] = 'Courses#destroy'