from system.core.controller import *

class Courses(Controller):
    def __init__(self, action):
        super(Courses, self).__init__(action)
        self.load_model('Course')
    def index(self):
        courses = self.models['Course'].get_all_courses()
        return self.load_view('index.html', courses=courses)
    def create(self):
        if len(request.form['course_name']) < 1:
            flash('Course name cannot be empty!')
            return redirect('/')
        elif len(request.form['course_name']) < 15:
            flash('Course name must have at least 15 characters!')
            return redirect('/')
        course_details = {
            'title': request.form['course_name'],
            'description': request.form['course_description']
        }
        self.models['Course'].add_course(course_details)
        flash('Course added!')
        return redirect('/')
    def destroy_page(self, course_id):
        course = self.models['Course'].get_course_by_id(course_id)
        print 'WE ARE IN DESTROY_PAGE!!! course:'
        print course
        return self.load_view('destroy_page.html', course=course[0])
    def destroy(self, course_id):
        self.models['Course'].delete_course(course_id)
        flash('Course deleted!')
        return redirect('/')
